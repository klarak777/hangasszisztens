# Real-time Voice Assistant with Next.js and ElevenLabs

This project demonstrates how to build a real-time voice assistant using Next.js and the ElevenLabs Conversational SDK. Follow along with the YouTube tutorial to create your own AI-powered voice assistant.
